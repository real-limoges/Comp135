python perceptron.py -eta 0.01 vertebrate_train_nonoise.arff vertebrate_test_nonoise.arff output.arff
